# SOP: Feastables Sales Scrollytelling Generation

## 1. Goal
Create a Next.js 14 scrollytelling landing page where Feastables chocolate bars "explode" to reveal sales metrics.

## 2. Tools & Scripts
- **Sourcing:** `execution/fetch_sales_data.py` (Kaggle API simulation)
- **Visuals:** `execution/video_to_frames.py` (FFmpeg/OpenCV processing)
- **Build:** Next.js App Router + Framer Motion

## 3. Data Requirements
- Revenue totals for 2024 and 2025.
- Ingredient breakdown for "exploded" view sync.

## 4. Output
- `tmp/processed_sales.json`: The data source for the UI.
- `public/assets/frames/`: 120-frame sequence.
