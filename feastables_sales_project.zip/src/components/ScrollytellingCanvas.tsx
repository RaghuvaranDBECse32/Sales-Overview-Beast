'use client';
import { useScroll, useTransform, motion } from 'framer-motion';
import { useEffect, useRef, useState } from 'react';

export default function ScrollytellingCanvas({ salesData }) {
    const containerRef = useRef(null);
    const canvasRef = useRef(null);
    const [images, setImages] = useState([]);
    const { scrollYProgress } = useScroll({ target: containerRef, offset: ['start start', 'end end'] });
    const frameIndex = useTransform(scrollYProgress, [0, 1], [0, 119]);

    useEffect(() => {
        // Preload logic (Simulation)
        const preload = async () => {
            const loaded = [];
            for (let i = 0; i < 120; i++) {
                const img = new Image();
                img.src = `/assets/frames/frame_${String(i).padStart(3, '0')}.webp`;
                loaded.push(img);
            }
            setImages(loaded);
        };
        preload();
    }, []);

    useEffect(() => {
        const render = () => {
            const ctx = canvasRef.current?.getContext('2d');
            if (ctx && images[Math.floor(frameIndex.get())]) {
                const img = images[Math.floor(frameIndex.get())];
                ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
                ctx.drawImage(img, 0, 0, ctx.canvas.width, ctx.canvas.height);
            }
        };
        return frameIndex.onChange(render);
    }, [images, frameIndex]);

    return (
        <div ref={containerRef} className="relative h-[400vh] bg-[#050505]">
            <div className="sticky top-0 h-screen w-full flex items-center justify-center">
                <canvas ref={canvasRef} width={1920} height={1080} className="w-full h-full object-cover" />
                <Overlays progress={scrollYProgress} data={salesData} />
            </div>
        </div>
    );
}

function Overlays({ progress, data }) {
    const opacity1 = useTransform(progress, [0, 0.1, 0.2], [0, 1, 0]);
    const opacity2 = useTransform(progress, [0.4, 0.5, 0.6], [0, 1, 0]);
    const opacity3 = useTransform(progress, [0.8, 0.9, 1], [0, 1, 1]);

    return (
        <div className="absolute inset-0 flex items-center justify-center text-white pointer-events-none">
            <motion.div style={{ opacity: opacity1 }} className="text-center">
                <h1 className="text-8xl font-black tracking-tighter">FEASTABLES</h1>
                <p className="text-2xl text-white/50 uppercase tracking-widest">The {data.valuation} Revolution</p>
            </motion.div>
            
            <motion.div style={{ opacity: opacity2 }} className="absolute left-20 max-w-lg">
                <h2 className="text-5xl font-bold">Explosive Growth</h2>
                <p className="text-xl text-white/60 mt-4">2024 Revenue: {data.revenue_2024}</p>
                <p className="text-3xl font-bold text-teal-400">Target 2025: {data.revenue_2025_target}</p>
            </motion.div>

            <motion.div style={{ opacity: opacity3 }} className="text-center">
                <h2 className="text-6xl font-bold italic">DECONSTRUCTED</h2>
                <div className="flex gap-4 mt-8">
                    {data.ingredients?.map(ing => (
                        <span key={ing} className="px-4 py-2 border border-white/20 rounded-full text-sm">{ing}</span>
                    ))}
                </div>
            </motion.div>
        </div>
    );
}
