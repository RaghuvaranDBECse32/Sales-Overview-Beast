import json
import os

def process_feastables_data():
    data = {
        "revenue_2024": "$251M",
        "revenue_2025_target": "$520M",
        "stores": "50,000+",
        "valuation": "$5B",
        "ingredients": ["Ethical Cocoa", "Cane Sugar", "Milk", "Rice Crunchies"]
    }
    os.makedirs('tmp', exist_ok=True)
    with open('tmp/processed_sales.json', 'w') as f:
        json.dump(data, f, indent=4)
    print("Layer 3: Sales data successfully cached in /tmp")

if __name__ == '__main__':
    process_feastables_data()
